package com.example.ejercicio3;


public class ejercicio {
    public static void main(String[] args) {
        Coche coche = new Coche();
        System.out.println(coche.velocidadActual);
        coche.acelerar();
        System.out.println(coche.velocidadActual);

        Coche coche2 = new Coche();
        coche2.acelerar();
        coche2.acelerar();
        System.out.println(coche2.velocidadActual);

    }
}
class Coche {
    int numeroDePuertas;
    int velocidadMaxima;
    float velocidadActual;

    public void acelerar () {
        velocidadActual += 15;
    }
    public void decelerar (){}

}